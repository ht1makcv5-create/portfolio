import { createHmac, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";

export const ADMIN_TELEGRAM_ID = 8689285693;
const COOKIE_NAME = "portfolio_admin_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 14;

type SessionPayload = {
  id: number;
  firstName: string;
  username?: string;
  exp: number;
};

function secret(): string {
  const value = process.env.SESSION_SECRET;
  if (!value) {
    throw new Error("SESSION_SECRET must be configured");
  }
  return value;
}

function sign(value: string): string {
  return createHmac("sha256", secret()).update(value).digest("base64url");
}

function encode(payload: SessionPayload): string {
  const value = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${value}.${sign(value)}`;
}

function decode(value: string | undefined): SessionPayload | null {
  if (!value) return null;
  const [encoded, received] = value.split(".");
  if (!encoded || !received) return null;
  const expected = sign(encoded);
  const receivedBuffer = Buffer.from(received);
  const expectedBuffer = Buffer.from(expected);
  if (
    receivedBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(receivedBuffer, expectedBuffer)
  ) {
    return null;
  }
  try {
    const parsed = JSON.parse(
      Buffer.from(encoded, "base64url").toString("utf8"),
    ) as SessionPayload;
    if (
      parsed.id !== ADMIN_TELEGRAM_ID ||
      !parsed.exp ||
      parsed.exp < Math.floor(Date.now() / 1000)
    ) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function setAdminSession(
  response: Response,
  session: Omit<SessionPayload, "exp">,
): void {
  response.cookie(
    COOKIE_NAME,
    encode({
      ...session,
      exp: Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS,
    }),
    {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: MAX_AGE_SECONDS * 1000,
      path: "/",
    },
  );
}

export function clearAdminSession(response: Response): void {
  response.clearCookie(COOKIE_NAME, { path: "/" });
}

export function getAdminSession(request: Request): SessionPayload | null {
  return decode(request.cookies?.[COOKIE_NAME]);
}

export function requireAdmin(request: Request, response: Response): boolean {
  if (getAdminSession(request)) return true;
  response.status(401).json({ error: "Admin session required" });
  return false;
}