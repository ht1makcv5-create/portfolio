# Yana Creative Studio

Українське портфоліо дизайнерки з формами для звернень і замовлень та закритим робочим простором для їх обробки.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/portfolio-site` — публічне портфоліо й адмін-панель.
- `artifacts/api-server` — API для заявок, статистики, Telegram-сповіщень і сесій.
- `lib/api-spec/openapi.yaml` — контракт API та джерело для згенерованих клієнтів.
- `lib/db/src/schema/requests.ts` — таблиця заявок у PostgreSQL.

## Architecture decisions

- Заявки приймаються публічно, але список і статистика доступні лише після підписаного Telegram-сеансу.
- Telegram-авторизація перевіряє підпис від бота та дозволяє тільки адміністратора з ID `8689285693`.
- Токен Telegram зберігається тільки в захищеному секреті `TELEGRAM_BOT_TOKEN`.

## Product

Користувачі можуть переглянути роботи, опис підходу та надіслати контактну заявку або замовлення. Власник бачить заявки, статистику, фільтри й може переводити звернення між статусами; кожна нова заявка також надсилається в Telegram-бот.

## User preferences

Не показувати секрети в чаті або клієнтському коді. Адмін-доступ — тільки Telegram ID `8689285693`.

## Gotchas

Після змін `lib/api-spec/openapi.yaml` потрібно виконувати `pnpm --filter @workspace/api-spec run codegen`. Секрет `TELEGRAM_BOT_TOKEN` має бути налаштований перед запуском API.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
